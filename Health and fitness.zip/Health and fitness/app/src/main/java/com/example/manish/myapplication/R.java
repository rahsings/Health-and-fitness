package com.example.manish.myapplication;

interface R {
    int drawer_layout = 0;
}
