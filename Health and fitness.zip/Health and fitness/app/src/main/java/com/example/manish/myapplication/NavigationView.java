package com.example.manish.myapplication;

import android.support.annotation.NonNull;
import android.view.MenuItem;

class NavigationView {
    public interface OnNavigationItemSelectedListener {
        boolean onNavigationItemSelected(@NonNull MenuItem item);
    }
}
